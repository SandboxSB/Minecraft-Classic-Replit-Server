Portions from ...

https://www.classicube.net/forum/viewpost/759-ocd_texture_pack/
https://123dmwm.com/texturepacks/oCdPack.zip
https://123dmwm.com/texturepacks/TinyPixels.zip
http://www.classicube.net/static/default.zip
